package logs

import (
	"os"
	"github.com/go-kit/kit/log/level"
	"github.com/go-kit/kit/log"
)

func InitLogs() (log.Logger) {


	var logger log.Logger
	logger = log.NewLogfmtLogger(os.Stdout)
	logger = level.NewFilter(logger, level.AllowInfo())
	logger = log.With(logger, "timestamp", log.DefaultTimestampUTC)
	return logger;
}
