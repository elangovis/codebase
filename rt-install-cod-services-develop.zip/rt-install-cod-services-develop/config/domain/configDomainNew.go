package common

type Config struct {
	ApiPort     string      `json:"api_port"`
	DbDetails   Credentials `json:"db_credentials"`
	DevUaa      UAADetails  `json:"dev_uaa_details"`
	QaUaa       UAADetails  `json:"qa_uaa_details"`
	ProdUaa     UAADetails  `json:"qa_uaa_details"`
	AuthEnabled bool        `json:"auth_enabled"`
	UaaHost     string      `json:"uaa_host"`
}

type UAADetails struct {
	ClientId     string `json:"clientId"`
	ClientSecret string `json:"clientSecret"`
}

type Credentials struct {
	ID         int    `json:"ID"`
	BindingId  string `json:"binding_id"`
	Database   string `json:"database"`
	Dsn        string `json:"dsn"`
	Host       string `json:"host"`
	InstanceId string `json:"instance_id"`
	JdbcUri    string `json:"jdbc_uri"`
	Password   string `json:"password"`
	Port       string `json:"port"`
	Uri        string `json:"uri"`
	Username   string `json:"username"`
	Sslmode    string `json:"sslmode"`
}

type DbConfiguration struct {
	Credentials Credentials `json:"credentials"`
	Label       string      `json:"label"`
	Name        string      `json:"name"`
	Plan        string      `json:"plan"`
	Tags        []string    `json:"tags"`
}

type DbService struct {
	Postgres []DbConfiguration `json:"postgres"`
}

