package common


type Configuration struct {
	Env string
}

type EnvConf struct {
	DB           DBStruct
	API          APIStruct
	Client       ClientStruct
	TmsHost      TmsHost
	Predix       Predix
	ContentType  ContentType
	ACS          ACSStruct
	TenantDBName TenantDBNameStruct
	Env	string
}
type DBStruct struct {
	User       string
	Password   string
	Server     string
	Connstring string
}
type APIStruct struct {
	UAA string
}

type ClientStruct struct {
	Token    string
	Id	 string
}

type ACSStruct struct {
	URL    string
	PredixZoneId	 string
}

type TmsHost struct {
	Uri    string
	DbType string
}

type Predix struct {
	ZoneId string
}

type ContentType struct {
	Type string
}

type TenantDBNameStruct struct{
	RealTrackTenantOilandGas string
	RealTrackTenantEnergyConnection string
}

var ConfigurationEnv *EnvConf