package common

type UAAResponse struct {
	Access_token string  `json:"access_token"`
	Token_type   string  `json:"token_type"`
	Expires_in   int  `json:"expires_in"`
	Scope        string  `json:"scope"`
	Jti          string  `json:"jti"`
}