package common



type Credentials struct {
	Allocated_storage  int `json:"allocated_storage"`
	Password           string `json:"password"`
	Hostname           string `json:"hostname"`
	Database           string `json:"database"`
	Port               int `json:"port"`
	Maintenance_window string `json:"maintenance_window"`
	Uri                string `json:"uri"`
	Uuid               string `json:"uuid"`
	Username           string `json:"username"`
}

type TmsDbBody struct {
	ServiceName         string `json:"serviceName"`
	ServiceInstanceName string `json:"serviceInstanceName"`
	ServiceInstanceId   string  `json:"serviceInstanceId"`
	Credentials         Credentials `json:"credentials"`
	StdCredentials      string  `json:"stdCredentials"`
	Scopes              string  `json:"scopes"`
	Status              string  `json:"status"`
	Description         string  `json:"description"`
	StatusMessage       string  `json:"statusMessage"`
	TenantId            string
}

type TmsDbResponse struct {
	TmsDbBody []TmsDbBody `json:""`
	TMSErrorResponse TMSErrorResponse
}

type TMSErrorResponse struct {
	Error             string  `json:"error"`
	Error_description string `json:"error_description"`
}
