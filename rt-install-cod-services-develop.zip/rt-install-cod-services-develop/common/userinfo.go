package common

/**
@Author: gamali
Date: 15-11-2017
Project :rt-install-cod-services
Description:
*/

type UserInfo struct {
	SSO       string
	LOGGEDSSO string
	ROLEID    string
	COMPANYID string
	FIRSTNAME string
	LASTNAME  string
	EMAIL     string
	USERNAME  string
	TITLE     string
}