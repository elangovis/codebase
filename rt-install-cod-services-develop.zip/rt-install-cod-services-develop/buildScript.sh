if [[ $VERBOSE == true ]]; then
  verbose="-v"
fi

export GOROOT=/usr/local/go
export GOPATH=$WORKSPACE
export GOBIN=$GOPATH/bin
export PATH=$PATH:$GOPATH/bin:$GOBIN:$GOROOT/bin

echo "GOPATH Direcotry: $GOPATH"
echo "GOROOT Directory: $GOROOT"

echo "Present directory Content"

ls -la

cd $WORKSPACE/src/github.build.ge.com/RealTrack/rt-install-cod-services

echo "Present working directory"
pwd

echo "Top level project code"
ls -la

go build

if [ $? -ne 0 ];
then
    echo "Failed to perform Go Build."
    exit 1
fi

echo "Go Build Successful."

go get -u github.com/go-swagger/go-swagger/cmd/swagger

file="swagger.json"
if [ -f "$file" ]
then
	rm -rf $file
	echo "$file successfully deleted"
fi

swagger generate spec -o ./swagger.json
