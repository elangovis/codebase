
/**
@Author: Ganesh Mali
Date: 15-11-2017
Project :rt-install-cod-services
Description:
*/
package main

import (
	"encoding/json"
	"fmt"
	domainConfig "github.build.ge.com/RealTrack/rt-install-cod-services/config/domain"
	logConfig "github.build.ge.com/RealTrack/rt-install-cod-services/config/logs"
	rtdb "github.build.ge.com/RealTrack/rt-install-cod-services/db"
	routes "github.build.ge.com/RealTrack/rt-install-cod-services/routes"
	"github.build.ge.com/RealTrack/rt-install-cod-services/swagger"
	"github.com/go-kit/kit/log/level"
	"github.com/jmoiron/sqlx"
	_ "github.com/lib/pq"
	"io/ioutil"
	"net/http"
	"os"
)

func main() {
	//initlize logs
	logger := logConfig.InitLogs()

	var err error
	//file, err := os.Open("config/environments/configuration.json")
	//if err != nil {
	//	level.Error(logger).Log(
	//		"op", "decode_config",
	//		"desc", "unable to open environment configiration file :"+"configuration.json",
	//		"value", err.Error())
	//	return
	//}
	//
	//decoder := json.NewDecoder(file)
	//configuration := domainConfig.Configuration{}
	//err = decoder.Decode(&configuration)
	//if err != nil {
	//	level.Error(logger).Log(
	//		"op", "decode_config",
	//		"desc", "unable to decode enviornment configiration",
	//		"value", err.Error())
	//
	//}
	//
	//env := configuration.Env
	appEnv :=os.Getenv("APP_DEPLOY_ENV")
	if appEnv==""{
		appEnv="local"
	}
	fmt.Println("realtrack_env: ", appEnv)

	level.Info(logger).Log(
		"op", "get",
		"desc", "envrionment",
		"value", appEnv)

	fileEnv, err := os.Open("config/environments/conf_" + appEnv + ".json")
	if err != nil {
		level.Error(logger).Log(
			"op", "decode_config",
			"desc", "unable to open configuration file "+" environments/conf_"+appEnv+".json",
			"value", err.Error())
		return
	}

	decoderEnv := json.NewDecoder(fileEnv)
	err = decoderEnv.Decode(&domainConfig.ConfigurationEnv)
	if err != nil {
		level.Error(logger).Log(
			"op", "decode_config",
			"desc", "unable to decode enviornment configiration",
			"value", err.Error())
	}

	level.Info(logger).Log(
		"op", "get",
		"desc", "envrionment",
		"value", domainConfig.ConfigurationEnv)

	//This needs to be fixed as part of this storey , Are used by tests right now

	connstr := domainConfig.ConfigurationEnv.DB.Connstring
	level.Debug(logger).Log("op", "get",
		"desc", "connection_string",
		"value", connstr)

	rtdb.DBConX, err = sqlx.Open("postgres", connstr)
	defer rtdb.DBConX.Close()

	if err != nil {
		level.Error(logger).Log("op", "read",
			"desc", "error connectinig to postgre db",
			"value", err.Error())
	}
	level.Info(logger).Log("op", "db_connection",
		"desc", "successfully connected to db",
		"value", rtdb.DBConX) //check if else

	r := routes.HandleRequests()
	port := os.Getenv("PORT")
	if len(port) < 1 {
		port = "6868"
	}

	r.HandleFunc("/swagger", AddSwaggerRoute)
	httpHandler := routes.AuthMiddleware(r)

	error := http.ListenAndServe(":"+port, httpHandler) //Handler
	if nil != error {
		level.Error(logger).Log(
			"op", "http_request",
			"desc", "error connecting to server",
			"value", error.Error())
	} else {
		level.Info(logger).Log("op", "http_request",
			"desc", "successfully connected to server",
			"value", httpHandler)
	}
}

func AddSwaggerRoute(w http.ResponseWriter, r *http.Request) {
	logger := logConfig.InitLogs()
	file, err := ioutil.ReadFile("swagger.json")
	if err != nil {
		level.Error(logger).Log(
			"op", "http_get",
			"desc", "unable to read swagger.json",
			"value", err.Error())
	}
	swagger.ServeTemplate(w, string(file))
}
