package db

import (
	"github.build.ge.com/RealTrack/rt-install-cod-services/common"
	domainConfig "github.build.ge.com/RealTrack/rt-install-cod-services/config/domain"
	"github.com/go-kit/kit/log"
	"github.com/go-kit/kit/log/level"
	"github.com/jmoiron/sqlx"
	"strconv"
)

func GetCredentials(tmsDbResponse common.TmsDbResponse, logger log.Logger) string {

	user := tmsDbResponse.TmsDbBody[0].Credentials.Username
	password := tmsDbResponse.TmsDbBody[0].Credentials.Password
	host := tmsDbResponse.TmsDbBody[0].Credentials.Hostname
	//host := "localhost"
	port := tmsDbResponse.TmsDbBody[0].Credentials.Port
	//port := 8119
	var dbName string
	tenantId := tmsDbResponse.TmsDbBody[0].TenantId
	if tenantId == "realTrackTenantEnergyConnection" {
		dbName = domainConfig.ConfigurationEnv.TenantDBName.RealTrackTenantEnergyConnection //tmsDbResponse.TmsDbBody[0].Credentials.Database
	} else if tenantId == "realTrackTenantOilandGas" {
		dbName = domainConfig.ConfigurationEnv.TenantDBName.RealTrackTenantOilandGas
	}
	connString := "postgres://" + user + ":" + password + "@" + host + ":" + strconv.Itoa(port) + "/" + dbName + "?sslmode=disable"

	level.Debug(logger).Log("op", "db_connect",
		"desc", "connection_string",
		"value", connString)
	return connString
}

func OpenConnection(tmsDbResponse common.TmsDbResponse, logger log.Logger) (*sqlx.DB,error) {
	connection, err := sqlx.Open("postgres", GetCredentials(tmsDbResponse, logger))
	//connection.SetMaxOpenConns(50)// read from config
	//connection.SetMaxIdleConns(50)// read from config

	if err != nil {
		level.Error(logger).Log("op", "read", "desc", "error connectinig to postgre db", "value", err.Error())
	} else {
		level.Info(logger).Log("op", "db_connection", "desc", "successfully connected to db", "value", connection) //check if else
	}
	return connection,err
}
