package db

import (
	_ "github.com/lib/pq"
	"github.com/jmoiron/sqlx"
	"os"
	"fmt"
	"io/ioutil"
	"encoding/json"
	"github.com/jinzhu/gorm"
	"strings"
	domainConfig "github.build.ge.com/RealTrack/rt-install-cod-services/config/domain"
	config "github.build.ge.com/RealTrack/rt-install-cod-services/config/logs"
	"github.com/go-kit/kit/log/level"
	"github.com/go-kit/kit/log"
)

var (
	// DBCon is the connection handle
	// for the database
	DBConX *sqlx.DB
)

func GetDBConnection(dbType string, uri string) (*gorm.DB, error) {
	if dbType == "" {
		dbType = "postgres"
	}

	db, err := gorm.Open(dbType, uri)
	if err != nil {
		panic("failed to connect database")
	}
	return db, nil
}

func getLogger() (log.Logger) {
	logger := config.InitLogs()
	return logger;
}


func GetDBConfig(path string) string {
	var dbservice domainConfig.DbService
	var uri string

	vcapservices := os.Getenv("VCAP_SERVICES") // Service Name

	if vcapservices != "" {
		reader := strings.NewReader(vcapservices)
		decoder := json.NewDecoder(reader)
		err := decoder.Decode(&dbservice)
		if (err != nil) {
			level.Error(getLogger()).Log(
				"op", "decode_db_config",
				"desc", "error decoding database configurations ",
				"value", err.Error());
			return ""
		}
		credentials := dbservice.Postgres[0].Credentials
		uri = credentials.Dsn
	} else {
		uri = GetLocalDBConfig(path)
	}

	return uri
}

func GetLocalDBConfig(path string) string {
	pwd, err := os.Getwd()
	if err != nil {
		fmt.Println(err)
		os.Exit(1)
	}

	jsonFile, err := ioutil.ReadFile(pwd + path)
	if err != nil {
		fmt.Println("Error opening JSON file:", err)
		return ""
	}

	var config domainConfig.Config
	err = json.Unmarshal(jsonFile, &config)

	if err != nil {
		fmt.Print("Error:", err)
	}

	data := config.DbDetails
	uri := fmt.Sprintf("dbname=%s port=%s sslmode=%s user=%s password=%s", data.Database, data.Port, data.Sslmode, data.Username, data.Password)

	return uri
}

func GetApiPort() string {
	port := os.Getenv("VCAP_APP_PORT")

	if port == "" {
		port = "3030"
	}
	return port
}
