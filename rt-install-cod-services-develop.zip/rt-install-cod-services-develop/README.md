# rt-install-cod-services
Go service repository for modules- Install commercial operation date

This is a microservice project. Install COD  API is one of the functionality provided by this microservice.
Code is written in go language.(version 1.7)

We love and encourage pull requests from everyone. Before submitting major changes, here are a few guidelines to follow:

1.Check the open issues and pull requests for existing discussions. 2.Open an issue first, to discuss a new feature or enhancement. 3.Write tests, and make sure the test suite passes locally and on CI. 4.Open a pull request, and reference the relevant issue(s). 5.After receiving feedback, squash your commits (http://gitready.com/advanced/2009/02/10/squashing-commits-with-rebase.html) and add a great commit message (http://tbaggery.com/2008/04/19/a-note-about-git-commit-messages.html)

Get Started

1.git clone git@github.build.ge.com:RealTrack/rt-install-cod-services.git

go build


Developers

Ganesh Mail :ganesh.mali1@bhge.com ,Ganesh Awate Any code review/comments are welcome.
