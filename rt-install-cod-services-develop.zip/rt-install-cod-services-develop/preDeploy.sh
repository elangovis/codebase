#!/bin/bash
# In this example, the pipeline is defined as follows in the Jenkinsfile:
#
#   pipeline =  [
#                   'development': ['predixSpace': 'SPACE_DEV', 'manifestFile': 'manifest-dev.yml', 'blueGreen': false],
#                   'qa': ['predixSpace': 'SPACE_INTEG', 'manifestFile': 'manifest-qa.yml', 'blueGreen': false]
#               ]
#
# the default case will cause the pipeline to stop.  Remove the exit line to disable this.

case $1 in
develop)
    cat $WORKSPACE/src/github.build.ge.com/RealTrack/rt-install-cod-services/config/environments/configuration.json
    echo 'starting dev steps...'
    sed -i 's|\"Env\":\"local\"|\"Env\":\"dev\"|g' $WORKSPACE/src/github.build.ge.com/RealTrack/rt-install-cod-services/config/environments/configuration.json
    cat $WORKSPACE/src/github.build.ge.com/RealTrack/rt-install-cod-services/config/environments/configuration.json
    ;;
qa)
    cat $WORKSPACE/src/github.build.ge.com/RealTrack/rt-install-cod-services/config/environments/configuration.json
    echo 'starting qa steps...'
    sed -i 's|\"Env\":\"local\"|\"Env\":\"qa\"|g' $WORKSPACE/src/github.build.ge.com/RealTrack/rt-install-cod-services/config/environments/configuration.json
    echo 'doing qa steps...'
    cat $WORKSPACE/src/github.build.ge.com/RealTrack/rt-install-cod-services/config/environments/configuration.json
    ;;
stg)
    cat $WORKSPACE/src/github.build.ge.com/RealTrack/rt-install-cod-services/config/environments/configuration.json
    echo 'starting stg steps...'
    sed -i 's|\"Env\":\"local\"|\"Env\":\"stg\"|g' $WORKSPACE/src/github.build.ge.com/RealTrack/rt-install-cod-services/config/environments/configuration.json
    echo 'doing stg steps...'
    cat $WORKSPACE/src/github.build.ge.com/RealTrack/rt-install-cod-services/config/environments/configuration.json
    ;;
prod)
    cat $WORKSPACE/src/github.build.ge.com/RealTrack/rt-install-cod-services/config/environments/configuration.json
    echo 'starting prod steps...'
    sed -i 's|\"Env\":\"local\"|\"Env\":\"prod\"|g' $WORKSPACE/src/github.build.ge.com/RealTrack/rt-install-cod-services/config/environments/configuration.json
    echo 'doing prod steps...'
    cat $WORKSPACE/src/github.build.ge.com/RealTrack/rt-install-cod-services/config/environments/configuration.json
    ;;
*)
    echo 'invalid argument!'
    exit 1
    ;;
esac
