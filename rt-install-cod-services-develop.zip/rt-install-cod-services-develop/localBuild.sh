#!/usr/bin/env bash

file="swagger.json"
if [ -f "$file" ]
then
	rm -rf $file
	echo "$file successfully deleted"
fi

echo "creating swagger json..."
swagger generate spec -o ./swagger.json
echo "$file successfully created swagger.json"
echo "Starting application...."
go run main.go