/**
@Author: Ganesh Mali
Date: 15-11-2017
Project :rt-install-cod-services
Description:
*/
package install

import (
	"github.build.ge.com/RealTrack/rt-install-cod-services/common"
)

type InstallationMilestonesService struct {
	RRef InstallationMilestonesRepository
}

//Installation Milestones
func (sRef *InstallationMilestonesService) MilestonesCountService(tenantId string, tmsDbResponse common.TmsDbResponse, param map[string]string) (InstallationMilestonesCount, error) {
	resp, err := sRef.RRef.MilestonesCountDetails(tenantId, tmsDbResponse, param)
	return resp, err
}

func (sRef *InstallationMilestonesService) MilestonesDetails(tenantId string, tmsDbResponse common.TmsDbResponse, param map[string]string) (InstallDetailsResp, error) {
	resp, err := sRef.RRef.MilestonesDetails(tenantId, tmsDbResponse, param)
	return resp, err
}

//Installation Resources
func (sRef *InstallationMilestonesService) ResourcesSummaryService(tenantId string, tmsDbResponse common.TmsDbResponse, param map[string]string) (map[string]interface{}, error) {
	resp, err := sRef.RRef.ResourcesSummary(tenantId, tmsDbResponse, param)
	return resp, err
}
func (sRef *InstallationMilestonesService) ResourcesDetailsService(tenantId string, tmsDbResponse common.TmsDbResponse, param map[string]string) (map[string][]ResourcesDetailsResponseModel, error) {
	resp, err := sRef.RRef.ResourcesDetails(tenantId, tmsDbResponse, param)
	return resp, err
}

//Tech Queries - Missing Materials
func (sRef *InstallationMilestonesService) TechQueriesDetailsService(tenantId string, tmsDbResponse common.TmsDbResponse, param map[string]string) (map[string](map[string]LegendResponseModel), error) {
	resp, err := sRef.RRef.TechQueriesDetails(tenantId, tmsDbResponse, param)
	return resp, err
}

func (sRef *InstallationMilestonesService) TechQueriesUpdatedOnService(tenantId string, tmsDbResponse common.TmsDbResponse, param map[string]string) (map[string]string, error) {
	resp, err := sRef.RRef.TechQueriesUpdatedOn(tenantId, tmsDbResponse, param)
	return resp, err
}
