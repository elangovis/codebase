/**
@Author: Ganesh Mali
Date: 15-11-2017
Project :rt-install-cod-services
Description:
*/

package install

//This is for Milestones Count for a Project
//swagger:parameters MilestonesCountSWRequest
type MilestonesCountRequest struct {
	//in: query
	// required:true
	ProjectId string `json:"project-id"`
	// in:header
	// required:true
	Authorization string `json:"Authorization"`
	// in:header
	// required:true
	//enum: realTrackTenantOilandGas, realTrackTenantEnergyConnection
	TenantName string `json:"TenantName"`
}

//This is for Milestones details for a Project
//swagger:parameters MilestonesDetailsSWRequest
type MilestonesDetailsRequest struct {
	//in: query
	// required:true
	ProjectId string `json:"project-id"`
	// in:header
	// required:true
	Authorization string `json:"Authorization"`
	// in:header
	// required:true
	//enum: realTrackTenantOilandGas, realTrackTenantEnergyConnection
	TenantName string `json:"TenantName"`
}


//This is for Resource Summary for a Project
//swagger:parameters ResourceSummarySWRequest
type ResourceSummaryRequest struct {
	//in: query
	// required:true
	ProjectId string `json:"project-id"`
	// in:header
	// required:true
	Authorization string `json:"Authorization"`
	// in:header
	// required:true
	//enum: realTrackTenantOilandGas, realTrackTenantEnergyConnection
	TenantName string `json:"TenantName"`
}


//This is for Resources Details for a Project
//swagger:parameters ResourceDetailsSWRequest
type ResourceDetailsRequest struct {
	//in: query
	// required:true
	ProjectId string `json:"project-id"`
	//in: query
	// required:true
	ResourceStatus string `json:"resource-status"`
	// in:header
	// required:true
	Authorization string `json:"Authorization"`
	// in:header
	// required:true
	//enum: realTrackTenantOilandGas, realTrackTenantEnergyConnection
	TenantName string `json:"TenantName"`
}


//This is for Tech Queries or Missing Materials  Details
//swagger:parameters TechQueriesDetailsSWRequest
type TechQueriesDetails struct {
	//in: query
	// required:true
	ProjectId string `json:"project-id"`
	// in:header
	// required:true
	Authorization string `json:"Authorization"`
	// in:header
	// required:true
	//enum: realTrackTenantOilandGas, realTrackTenantEnergyConnection
	TenantName string `json:"TenantName"`
}