/**
@Author: Ganesh Mali
Date: 15-11-2017
Project :rt-install-cod-services
Description:
*/

package install

import (
	"github.build.ge.com/RealTrack/rt-install-cod-services/common"
	logConfig "github.build.ge.com/RealTrack/rt-install-cod-services/config/logs"
	rtdb "github.build.ge.com/RealTrack/rt-install-cod-services/db"
	"github.com/go-kit/kit/log/level"
	"gopkg.in/axiomzen/null.v6"
	"strings"
)

type InstallationMilestonesRepository struct {
	// Db *gorm.DB // Use of orm
}

func (r *InstallationMilestonesRepository) MilestonesCountDetails(tenantId string, tmsDbResponse common.TmsDbResponse, param map[string]string) (InstallationMilestonesCount, error) {

	logger := logConfig.InitLogs()
	var errReturn error
	MilestoneDBResponse := []InstallationMilestonesCount{}
	responseModel := InstallationMilestonesCount{}

	connection, errConn := rtdb.OpenConnection(tmsDbResponse, logger)
	if errConn != nil {
		return responseModel, errConn
	}
	defer connection.Close()

	errCount := connection.Select(&MilestoneDBResponse, sqlMilestonesCount, param["project-id"])
	if errCount != nil {
		return responseModel, errCount
	}

	if len(MilestoneDBResponse) > 0 {
		responseModel = MilestoneDBResponse[0]
	}

	level.Debug(logger).Log("op", "db_connection", "desc", "successfully closed MaterialStatus for tenent: "+tenantId)
	return responseModel, errReturn

}

func (r *InstallationMilestonesRepository) MilestonesDetails(tenantId string, tmsDbResponse common.TmsDbResponse, param map[string]string) (InstallDetailsResp, error) {

	logger := logConfig.InitLogs()
	jobNumbers := []null.String{}
	trains := []Train{}
	milestones := []MileStone{}
	responseModel := InstallDetailsResp{}

	connection, errConn := rtdb.OpenConnection(tmsDbResponse, logger)
	if errConn != nil {
		return responseModel, errConn
	}
	defer connection.Close()

	err := connection.Select(&jobNumbers, sqlMilestones_Jobs, param["project-id"])
	if err != nil {
		return responseModel, err
	}
	err = connection.Select(&trains, sqlMilestones_Trains, param["project-id"])
	if err != nil {
		return responseModel, err
	}
	err = connection.Select(&milestones, sqlMilestones, param["project-id"])
	if err != nil {
		return responseModel, err
	}

	jobNumbersResp := []JobsResp{}

	for _, job := range jobNumbers {
		jobResp := JobsResp{}
		jobResp.JobNumber = job
		trainRespArr := []TrainResp{}

		for _, train := range trains {

			if job == train.JOB_NUMBER {
				trainResp := TrainResp{}
				milestonesResp := []MileStone{}
				trainResp.TrainName = train.WBS_NAME
				trainResp.JobNumber = train.JOB_NUMBER
				trainResp.CompletedMiles = train.COMPLETED_MILESTONES
				trainResp.TotalMiles = train.TOTAL_MILESTONES

				for _, milestone := range milestones {

					if train.WBS_NAME == milestone.WBS_NAME {
						milestonesResp = append(milestonesResp, milestone)

					}

				} //milestone ends here
				trainResp.Milestones = milestonesResp
				trainRespArr = append(trainRespArr, trainResp)

			}

		} //train ends here
		jobResp.Trains = trainRespArr
		jobNumbersResp = append(jobNumbersResp, jobResp)

	}
	responseModel.Jobs = jobNumbersResp

	level.Debug(logger).Log("op", "db_connection", "desc", "successfully closed MilestonesDetails for tenent: "+tenantId)
	return responseModel, err

}

func (r *InstallationMilestonesRepository) ResourcesSummary(tenantId string, tmsDbResponse common.TmsDbResponse, param map[string]string) (map[string]interface{}, error) {

	logger := logConfig.InitLogs()
	var errReturn error
	var activityCount []int64
	var mgrName []string

	responseModel := []ResourcesAsgnmntResponseModel{}
	responseMap := make(map[string]interface{})

	connection, errConn := rtdb.OpenConnection(tmsDbResponse, logger)
	if errConn != nil {
		return responseMap, errConn
	}
	defer connection.Close()

	errResourceCount := connection.Select(&responseModel, sqlResourceCount, param["project-id"])
	if errResourceCount != nil {
		return responseMap, errResourceCount
	}

	errActivityCount := connection.Select(&activityCount, sqlResources_ActivityCount, param["project-id"])
	if errActivityCount != nil {
		return responseMap, errActivityCount
	}

	errInstallMgr := connection.Select(&mgrName, sqlResources_installMgr, param["project-id"])
	if errInstallMgr != nil {
		return responseMap, errInstallMgr
	}

	//For Resources and Status
	if len(responseModel) > 0 {
		for _, thisResource := range responseModel {
			responseMap[thisResource.RESOURCE_STATUS] = thisResource.ASSIGNMENT_OVERVIEW
		}
	}

	//For Activity Count - check if Activity exist or not for given project Id.
	if len(activityCount) > 0 {
		responseMap["projectCount"] = activityCount[0]

	}

	if len(mgrName) > 0 {
		responseMap["installationMgr"] = mgrName[0]

	}

	level.Debug(logger).Log("op", "db_connection", "desc", "successfully closed ResourcesAssignmentDetails for tenent: "+tenantId)
	return responseMap, errReturn

}

func (r *InstallationMilestonesRepository) ResourcesDetails(tenantId string, tmsDbResponse common.TmsDbResponse, param map[string]string) (map[string][]ResourcesDetailsResponseModel, error) {

	logger := logConfig.InitLogs()
	var errReturn error
	responseModel := []ResourcesDetailsResponseModel{}
	responseMap := make(map[string][]ResourcesDetailsResponseModel)
	var sqlString string

	connection, errConn := rtdb.OpenConnection(tmsDbResponse, logger)
	if errConn != nil {
		return responseMap, errConn
	}
	defer connection.Close()

	if (param["resource-status"]) == "on_site" {
		sqlString = sqlResources_OnSite
	} else if (param["resource-status"]) == "waiting_for_mobilization" {
		sqlString = sqlResources_WaitingForMobilization
	} else {
		sqlString = sqlResources_OnHold
	}

	errResourceCount := connection.Select(&responseModel, sqlString, param["project-id"])
	if errResourceCount != nil {
		return responseMap, errResourceCount
	}

	//Preparing the response map
	if len(responseModel) > 0 {
		responseMap["Response"] = responseModel
	}

	level.Debug(logger).Log("op", "db_connection", "desc", "successfully closed ResourcesAssignmentDetails for tenent: "+tenantId)
	return responseMap, errReturn

}

func (r *InstallationMilestonesRepository) TechQueriesDetails(tenantId string, tmsDbResponse common.TmsDbResponse, param map[string]string) (map[string](map[string]LegendResponseModel), error) {

	logger := logConfig.InitLogs()
	var errReturn error
	var chartType string

	issueList := []IssueDataModel{}
	responseMap := map[string]map[string]LegendResponseModel{}

	responseMap["aging"] = map[string]LegendResponseModel{}
	responseMap["cycle"] = map[string]LegendResponseModel{}

	connection, errConn := rtdb.OpenConnection(tmsDbResponse, logger)
	defer connection.Close()
	if errConn != nil {
		return responseMap, errConn
	}

	errTechQueries := connection.Select(&issueList, sqlTechQueries_Summary, param["project-id"])
	if errTechQueries != nil {
		return responseMap, errTechQueries
	}

	for _, thisIssue := range issueList {

		if strings.ToLower(thisIssue.ISSUE_STATE) == "closure" {
			chartType = "cycle"
		} else {
			chartType = "aging"
		}
		_, exist := responseMap[chartType][thisIssue.INTERVAL]

		if exist {
			existingIntervalValue := responseMap[chartType][thisIssue.INTERVAL]
			existingIntervalData := existingIntervalValue.LegendIssueData
			appendIssueData := append(existingIntervalData, thisIssue)
			existingIntervalValue.LegendIssueData = appendIssueData
			responseMap[chartType][thisIssue.INTERVAL] = existingIntervalValue
		} else {
			thisIssueResponse := LegendResponseModel{}
			thisIssueResponse.LegendColor = thisIssue.DISPLAYCOLOR
			thisIssueResponse.LegendIssueData = append(thisIssueResponse.LegendIssueData, thisIssue)
			responseMap[chartType][thisIssue.INTERVAL] = thisIssueResponse
		}
	}

	level.Debug(logger).Log("op", "db_connection", "desc", "successfully closed TechQueriesDetails for tenent: "+tenantId)
	return responseMap, errReturn

}

func (r *InstallationMilestonesRepository) TechQueriesUpdatedOn(tenantId string, tmsDbResponse common.TmsDbResponse, param map[string]string) (map[string]string, error) {

	logger := logConfig.InitLogs()
	var errReturn error

	updatedOn := []null.String{}
	responseMap := map[string]string{}

	connection, errConn := rtdb.OpenConnection(tmsDbResponse, logger)
	defer connection.Close()
	if errConn != nil {
		return responseMap, errConn
	}

	errTechQueries := connection.Select(&updatedOn, sqlTechQueries_UpdatedOn, param["project-id"])
	if errTechQueries != nil {
		return responseMap, errTechQueries
	}

	if len(updatedOn) > 0 {
		responseMap["updateOn"] = updatedOn[0].String
	}

	level.Debug(logger).Log("op", "db_connection", "desc", "successfully closed TechQueriesUpdatedOn for tenent: "+tenantId)
	return responseMap, errReturn

}
