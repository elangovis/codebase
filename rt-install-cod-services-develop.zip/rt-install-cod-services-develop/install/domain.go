/**
@Author: Ganesh Mali
Date: 15-11-2017
Project :rt-install-cod-services
Description:
*/
package install

import "gopkg.in/axiomzen/null.v6"

type InstallationMilestonesCount struct {
	PROJECT_COUNT null.Int64  `json:"projectCount"`
	UPDATED_DATE  null.String `json:"lastUpdateDate"`
	INSTAL_MGR_NM null.String `json:"managerNames"`
}

type MileStone struct {
	JOB_NUMBER          null.String `json:"jobNumber"`
	WBS_NAME            null.String `json:"train"`
	MILESTONE           null.String `json:"name"`
	PERCENT_COMPLETE    null.String `json:"complete"`
	PLANNED_ACTUAL_DATE null.String `json:"plannedActualDate"`
	CWD                 null.String `json:"customerWantDate"`
	PLANNED_ACTUAL_SORT null.String `json:"plannedActualSort"`
}

type Train struct {
	JOB_NUMBER           null.String `json:"jobNumber"`
	WBS_NAME             null.String `json:"train"`
	TOTAL_MILESTONES     null.String `json:"totalMilestones"`
	COMPLETED_MILESTONES null.String `json:"completedMilestones"`
}

type JobsResp struct {
	JobNumber null.String `json:"jobNumber"`
	Trains    []TrainResp `json:"trains"`
}
type InstallDetailsResp struct {
	Jobs []JobsResp `json:"jobs"`
}

type TrainResp struct {
	JobNumber      null.String `json:"jobNumber"`
	TrainName      null.String `json:"trainName"`
	TotalMiles     null.String `json:"totalMilestones"`
	CompletedMiles null.String `json:"completedMilestones"`
	Milestones     []MileStone `json:"milestones"`
}

type ResourcesAsgnmntResponseModel struct {
	RESOURCE_STATUS     string `json:"resourceStatus"`
	ASSIGNMENT_OVERVIEW int64  `json:"assignmentOverview"`
}

type ResourcesDetailsResponseModel struct {
	RESOURCE_STATUS       null.String `json:"resourceStatus"`
	FSE_USRNAME           null.String `json:"name"`
	FSE_USER_ROLE         null.String `json:"role"`
	ASSIGNMENT_SORT_START null.String `json:"assignmentSortStart"`
	ASSIGNMENT_SORT_END   null.String `json:"assignmentSortEnd"`
	ASSIGNMENT_START      null.String `json:"assignmentStart"`
	ASSIGNMENT_END        null.String `json:"assignmentEnd"`
}

type IssueDataModel struct {
	CASE_NUMBER         null.String `json:"caseNumber"`
	SRC_UPLOAD_DATE     null.String `json:"srcUploadDate"`
	ISSUE_EVENT_DATE    null.String `json:"issueEventDate"`
	OPENED_DATE         null.String `json:"opened"`
	TYPE_OF_ISSUE       null.String `json:"typeOfIssue"`
	PROBLEM_DESCRIPTION null.String `json:"problemDescription"`
	SITE_NAME           null.String `json:"siteName"`
	SITE_COUNTRY        null.String `json:"siteCountry"`
	ISSUE_STATE         string      `json:"issueState"`
	SRC_LAST_UPDATE_DT  null.String `json:"srcLastUpdate_dt"`
	CLOSED_DATE         null.String `json:"closedDate"`
	CYCLE_AGING_TIME    int64       `json:"cycleAgingTime"`
	INTERVAL            string      `json:"legendName"`
	DISPLAYCOLOR        null.String `json:"legendColor"`
}

type LegendResponseModel struct {
	LegendColor     null.String      `json:"legendColor"`
	LegendIssueData []IssueDataModel `json:"legendData"`
}
