
/**
@Author: Ganesh Mali
Date: 15-11-2017
Project :rt-install-cod-services
Description:
*/
package install

//Ok,Successful
//swagger:response InstallCodSuccessResponse
type InstallCodSuccessResponse struct {
	//in: body
	Message string `json:"message"`
}

//Not Ok,No Milestones found for Project.
//swagger:response InstallCodNotFoundResponse
type InstallCodNotFoundResponse struct {
	//in: body
	Status int `json:"status"`
}

//Authorization Failed
//swagger:response InstallCodAuthResponse
type InstallCodAuthResponse struct {
	//in: body
	Message string `json:"message"`
}

//Internal Server Error
//swagger:response InstallCodInternalServerErrorResponse
type InstallCodInternalServerErrorResponse struct {
	//in: body
	Message string `json:"message"`
}

//Bad Request
//swagger:response InstallCodParamErrorResponse
type InstallCodParamErrorResponse struct {
	//in: body
	Message string `json:"message"`
}