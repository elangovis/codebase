package install

/**
@Author: gaawate
Date: 11/28/2017
Project :rt-install-cod-services
Description: SQL Queries repository
*/

const (
	sqlMilestonesCount = "select count(distinct job_number) as project_count," +
		"to_char(max(insert_dt),'dd-MON-yyyy') updated_date,string_agg(distinct instal_mgr_nm,' & ') " +
		"instal_mgr_nm from rt_app.rt_cat_installation_activities " +
		"where project_id = $1 and instal_milestone_flag = 'Y'"

	sqlMilestones_Jobs = "Select distinct job_number FROM rt_app.rt_cat_installation_activities WHERE project_id = $1 " +
		"AND instal_milestone_flag = 'Y' AND task_type in ('Start Milestone','Finish Milestone')"

	sqlMilestones_Trains = "Select job_number,wbs_name ,total_milestone_cnt as total_milestones ,sum(completed_task) as completed_milestones " +
		"from (Select distinct job_number,wbs_name,count(task_id) over (partition by job_number,wbs_name) as total_milestone_cnt, " +
		"count(CASE WHEN is_complete = 'COMPLETED' THEN task_id END) over (partition by job_number,wbs_name,is_complete)  as completed_task, " +
		"is_complete FROM (Select distinct job_number, wbs_name,task_id,planned_start_date,planned_end_date, " +
		"(CASE  WHEN   task_type = 'Start Milestone' AND now() > planned_start_date THEN 'COMPLETED'" +
		"WHEN task_type = 'Finish Milestone' AND now() > planned_end_date THEN 'COMPLETED' ELSE 'NOT COMPLETED' END ) as is_complete " +
		"FROM rt_app.rt_cat_installation_activities WHERE project_id = $1 AND instal_milestone_flag = 'Y' " +
		"AND task_type in ('Start Milestone','Finish Milestone')) tmp ) tmp1  group by job_number,wbs_name, total_milestone_cnt " +
		"order by wbs_name"

	sqlMilestones = "select  tga.job_number,tga.wbs_name,tga.task_name as milestone,tgm.is_completed as percent_complete," +
		"to_char((case when tgm.planned_or_actual_dt is not null then tgm.planned_or_actual_dt else null end),'dd-MON-yyyy') as planned_actual_date," +
		"to_char((case when tgm.customer_want_date is not null then tgm.customer_want_date else null end),'dd-MON-yyyy') as cwd," +
		"to_char((case when tgm.planned_or_actual_dt is not null then tgm.planned_or_actual_dt else null end),'dd-MON-yyyy') as planned_actual_sort " +
		"from rt_app.rt_cat_installation_milestones tgm,rt_app.rt_cat_installation_activities tga " +
		"where tgm.instal_activity_id = tga.instal_activity_id and tga.project_id =$1 " +
		"order by tga.wbs_name ,tgm.planned_or_actual_dt"

	sqlResourceCount = "select distinct lower(substring(a.resource_status,1,1))||  " +
		"substring(translate(initcap(a.resource_status),' -',''),2) as resource_status,  " +
		"a.assignment_overview from   (select b.resource_status,  " +
		"count(b.instal_activity_id) over (partition by b.resource_status) as assignment_overview  " +
		"from   (Select instal_activity_id, project_id,resource_status ,activity_completed_pct ,  " +
		"fse_usrname,fse_user_role,user_assignment_start_date,user_assignment_end_date,planned_start_date,  " +
		"planned_end_date from   rt_app.rt_cat_installation_activities WHERE project_id like $1  " +
		"and resource_status in ('Assigned','Assigned - Warning','Waiting for Assignment','On Hold','Assignment Revision','Assignment Rejected')  " +
		"and upper(fse_user_role) != 'HQ_PERSONNEL') b) a " +
		"union select 'assignCurrent' as resource_status,  " +
		"count(a.instal_activity_id) as assignment_overview from (select instal_activity_id, project_id,  " +
		"resource_status, activity_completed_pct, fse_usrname, fse_user_role, user_assignment_start_date,  " +
		"user_assignment_end_date, planned_start_date, planned_end_date, to_char(insert_dt,'dd-mon-yyyy')  " +
		"from rt_app.rt_cat_installation_activities where project_id = $1 and resource_status in  " +
		"('Assigned','Assigned - Warning','Assignment Revision') and user_assignment_start_date <= insert_dt and  " +
		"user_assignment_end_date >= insert_dt and upper(fse_user_role) != 'HQ_PERSONNEL') a  " +
		"union select 'waitingAsCurrent' as resource_status, count(a.instal_activity_id) as assignment_overview  " +
		"from (select instal_activity_id, project_id, resource_status, activity_completed_pct,  " +
		"fse_usrname, fse_user_role, user_assignment_start_date, user_assignment_end_date, planned_start_date,  " +
		"planned_end_date from rt_app.rt_cat_installation_activities where project_id = $1 and resource_status in  " +
		"('Waiting for Assignment','Assignment Rejected') and planned_start_date > insert_dt and  " +
		"upper(fse_user_role) != 'HQ_PERSONNEL') a union select 'onHoldCurrent' as resource_status,  " +
		"count(a.instal_activity_id) as assignment_overview from (select instal_activity_id, project_id,  " +
		"resource_status, activity_completed_pct, fse_usrname, fse_user_role, user_assignment_start_date,  " +
		"user_assignment_end_date, planned_start_date, planned_end_date from rt_app.rt_cat_installation_activities  " +
		"where project_id = $1 and resource_status in ('On Hold') and planned_start_date > insert_dt and  " +
		"upper(fse_user_role) != 'HQ_PERSONNEL') a order by resource_status "

	sqlResources_ActivityCount = "select count(distinct project_id) as projectCount from  " +
		"rt_app.rt_cat_installation_activities WHERE project_id like $1"

	sqlResources_OnSite = "select a.resource_status,a.fse_usrname,a.fse_user_role, " +
		"(case when a.resource_status in ('Assigned','Assigned - Warning','Assignment Revision') then a.user_assignment_start_date  " +
		"else a.planned_start_date end) as assignment_sort_start,(case when a.resource_status in  " +
		"('Assigned','Assigned - Warning','Assignment Revision') then a.user_assignment_end_date  " +
		"else a.planned_end_date  end) as assignment_sort_end, " +
		"(case when a.resource_status in  " +
		"('Assigned','Assigned - Warning','Assignment Revision')  " +
		"then to_char(a.user_assignment_start_date,'DD-MON-YYYY')  " +
		"else to_char(a.planned_start_date,'DD-MON-YYYY')  end) as assignment_start, " +
		"(case when a.resource_status in ('Assigned','Assigned - Warning','Assignment Revision')  " +
		"then to_char(a.user_assignment_end_date,'DD-MON-YYYY')  " +
		"else to_char(a.planned_end_date,'DD-MON-YYYY') end) as assignment_end " +
		"from (select instal_activity_id,project_id,resource_status , " +
		"activity_completed_pct,coalesce(fse_usrname,'FSE Assigned') as fse_usrname, " +
		"coalesce(fse_user_role,'Not Available') as fse_user_role, user_assignment_start_date , " +
		"user_assignment_end_date,planned_start_date,planned_end_date  " +
		"from rt_app.rt_cat_installation_activities where project_id like $1  " +
		"and resource_status in ('Assigned','Assigned - Warning','Assignment Revision') " +
		"and upper(fse_user_role) != 'HQ_PERSONNEL')  a " +
		"order by assignment_sort_start, assignment_sort_end, resource_status, fse_usrname "

	sqlResources_WaitingForMobilization = "select a.resource_status,a.fse_usrname,a.fse_user_role, " +
		"(case when a.resource_status in ('Assigned','Assigned - Warning','Assignment Revision') then a.user_assignment_start_date  " +
		"else a.planned_start_date end) as assignment_sort_start,(case when a.resource_status in  " +
		"('Assigned','Assigned - Warning','Assignment Revision') then a.user_assignment_end_date  " +
		"else a.planned_end_date  end) as assignment_sort_end, " +
		"(case when a.resource_status in  " +
		"('Assigned','Assigned - Warning','Assignment Revision')  " +
		"then to_char(a.user_assignment_start_date,'DD-MON-YYYY')  " +
		"else to_char(a.planned_start_date,'DD-MON-YYYY')  end) as assignment_start, " +
		"(case when a.resource_status in ('Assigned','Assigned - Warning','Assignment Revision')  " +
		"then to_char(a.user_assignment_end_date,'DD-MON-YYYY')  " +
		"else to_char(a.planned_end_date,'DD-MON-YYYY') end) as assignment_end " +
		"from (select instal_activity_id,project_id,resource_status , " +
		"activity_completed_pct,coalesce(fse_usrname,'To be Assigned') as fse_usrname, " +
		"coalesce(fse_user_role,'Not Available') as fse_user_role, user_assignment_start_date , " +
		"user_assignment_end_date,planned_start_date,planned_end_date  " +
		"from rt_app.rt_cat_installation_activities where project_id like $1  " +
		"and resource_status in ('Waiting for Assignment','Assignment Rejected') " +
		"and upper(fse_user_role) != 'HQ_PERSONNEL')  a " +
		"order by assignment_sort_start, assignment_sort_end, resource_status, fse_usrname "

	sqlResources_OnHold = "select a.resource_status,a.fse_usrname,a.fse_user_role, " +
		"(case when a.resource_status in ('Assigned','Assigned - Warning','Assignment Revision') then a.user_assignment_start_date  " +
		"else a.planned_start_date end) as assignment_sort_start,(case when a.resource_status in  " +
		"('Assigned','Assigned - Warning','Assignment Revision') then a.user_assignment_end_date  " +
		"else a.planned_end_date  end) as assignment_sort_end, " +
		"(case when a.resource_status in  " +
		"('Assigned','Assigned - Warning','Assignment Revision')  " +
		"then to_char(a.user_assignment_start_date,'DD-MON-YYYY')  " +
		"else to_char(a.planned_start_date,'DD-MON-YYYY')  end) as assignment_start, " +
		"(case when a.resource_status in ('Assigned','Assigned - Warning','Assignment Revision')  " +
		"then to_char(a.user_assignment_end_date,'DD-MON-YYYY')  " +
		"else to_char(a.planned_end_date,'DD-MON-YYYY') end) as assignment_end " +
		"from (select instal_activity_id,project_id,resource_status , " +
		"activity_completed_pct,coalesce(fse_usrname,'To be Assigned') as fse_usrname, " +
		"coalesce(fse_user_role,'Not Available') as fse_user_role, user_assignment_start_date , " +
		"user_assignment_end_date,planned_start_date,planned_end_date  " +
		"from rt_app.rt_cat_installation_activities where project_id like $1  " +
		"and resource_status in ('On Hold') " +
		"and upper(fse_user_role) != 'HQ_PERSONNEL')  a " +
		"order by assignment_sort_start, assignment_sort_end, resource_status, fse_usrname "

	sqlTechQueries_Summary = "( " +
		"with " +
		" config as " +
		"  (select it.case_number, " +
		"          it.src_upload_date, " +
		"          to_char(it.issue_event_date, 'DD-MON-YYYY') AS issue_event_date, " +
		"          to_char(it.opened_date, 'DD-MON-YYYY') AS opened_date, " +
		"          it.current_type_of_issue AS type_of_issue, " +
		"          it.problem_description, " +
		"          it.site_name, " +
		"          it.site_country, " +
		"          it.issue_state, " +
		"          to_char(it.src_last_update_dt, 'DD-MON-YYYY') AS src_last_update_dt, " +
		"          to_char(it.closed_date, 'DD-MON-YYYY') AS closed_date, " +
		"          round(coalesce(case " +
		"                           when it.closed_date IS NULL THEN " +
		"                             (current_date - it.opened_date) " +
		"                           else " +
		"                             (it.closed_date - it.opened_date) " +
		"                         end, 0), 0) cycle_aging_time, " +
		"          ap.company_id               " +
		"   from   rt_app.rt_cat_install_tech  it, " +
		"          (select case_number, " +
		"                        max(src_upload_date) upd_dt " +
		"                 from rt_app.rt_cat_install_tech " +
		"                 group by case_number) mx_tbl, " +
		"                rt_app.rt_adm_project  ap " +
		"   where  it.current_type_of_issue IN ('Technical', 'Material') " +
		"   and    upper(it.issue_state) <> 'CANCELLED' " +
		"   and    it.customer_visibility in ('Yes') " +
		"   and    it.case_number = mx_tbl.case_number " +
		"   and    coalesce(it.src_upload_date,now()) = coalesce(mx_tbl.upd_dt,now()) " +
		"   and    it.project_id = ap.project_id " +
		"   and    it.project_id = $1" +
		"   order by it.case_number) " +
		"  " +
		"(select case_number, " +
		"         src_upload_date, " +
		"         issue_event_date, " +
		"         opened_date, " +
		"         type_of_issue, " +
		"         problem_description, " +
		"         site_name, " +
		"         site_country, " +
		"         issue_state, " +
		"         src_last_update_dt, " +
		"         closed_date, " +
		"         cycle_aging_time, " +
		"         (select interval_name " +
		"          from   rt_app.rt_cat_threshold_config  tc " +
		"          where  config.cycle_aging_time >= tc.start_value " +
		"          and    (case " +
		"                    when tc.end_value is not null then " +
		"                      config.cycle_aging_time <= tc.end_value " +
		"                    else " +
		"                       true " +
		"                  end) " +
		"          and    tc.kpi_identifier = (case " +
		"                                        when upper(config.issue_state) = 'CLOSURE' then " +
		"                                          'techqueries_cycle' " +
		"                                        else " +
		"                                          'techqueries_aging' " +
		"                                      end) " +
		"          and    config.company_id = tc.company_id) as Interval, " +
		"         (select color_code " +
		"          from   rt_app.rt_cat_threshold_config  tc " +
		"          where  config.cycle_aging_time >= tc.start_value " +
		"          and    (case " +
		"                    when tc.end_value is not null then " +
		"                      config.cycle_aging_time <= tc.end_value " +
		"                    else " +
		"                       true " +
		"                  end) " +
		"          and    tc.kpi_identifier = (case " +
		"                                        when upper(config.issue_state) = 'CLOSURE' then " +
		"                                          'techqueries_cycle' " +
		"                                        else " +
		"                                          'techqueries_aging' " +
		"                                      end) " +
		"          and    config.company_id = tc.company_id) as DisplayColor                 " +
		"  from  config))"

	sqlTechQueries_UpdatedOn = "select to_char(max(insert_dt),'dd-Mon-yyyy') updatedOn from   rt_app.rt_cat_install_tech where  project_id =$1"

	sqlResources_installMgr = "select string_agg(distinct instal_mgr_nm,' & ') instal_mgr_nm from rt_app.rt_cat_installation_activities where project_id =$1"
)
