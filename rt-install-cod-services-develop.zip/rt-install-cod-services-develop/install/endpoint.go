/**
@Author: Ganesh Mali
Date: 15-11-2017
Project :rt-install-cod-services
Description:
*/
package install

import (
	"encoding/json"
	domainConfig "github.build.ge.com/RealTrack/rt-install-cod-services/config/domain"
	logConfig "github.build.ge.com/RealTrack/rt-install-cod-services/config/logs"
	utilX "github.build.ge.com/RealTrack/rt-install-cod-services/utilx"
	"github.com/go-kit/kit/log/level"
	"net/http"
)

type InstallationMilestonesEndpoint struct {
	SRef InstallationMilestonesService
}

// swagger:route GET /v1/installation/milestonesCount Milestones MilestonesCountSWRequest
//
// Gets Count of milestones for a Project
//
// This will fetch number of milestones for given project.
//
//     Schemes: https
//     BasePath: /
//     Version: 0.0.1
//     License: GE Digital
//     Contact: Ganesh Awate<ganesh.awate@bhge.com>
//
//     Consumes:
//     - application/json
//
//     Produces:
//     - application/json
//
//     Security:
//       api_key:
//       oauth: read, write
//
//     SecurityDefinitions:
//     - api_key:
//          type: apiKey
//          name: KEY
//          in: header
//
//     Responses:
//
//       200: InstallCodSuccessResponse
//       500: InstallCodInternalServerErrorResponse
//       400: InstallCodParamErrorResponse
//       401: InstallCodAuthResponse
//       404: InstallCodNotFoundResponse

func (eRef *InstallationMilestonesEndpoint) MilestonesCount(w http.ResponseWriter, r *http.Request) {

	logger := logConfig.InitLogs()
	queryParams := utilX.ParseQueryParams(r)
	tenantId, authToken := utilX.GetRequestHeader(r)

	if authToken == "" {
		level.Error(logger).Log(
			"op", "Authorization Error",
			"desc", "Invalid/Expired UAA Token")
		http.Error(w, "Invalid/Expired UAA Token", http.StatusUnauthorized)
	} else {
		defaultInputParams := []string{"project-id"}
		validFlag, validMessage := utilX.ValidateRequest(queryParams, defaultInputParams, tenantId)

		if validFlag == false {
			level.Error(logger).Log(
				"op", "decode_config",
				"desc", "Error in Decoding request for GetMilestonesCount for tenant:"+tenantId,
				"value", validMessage)
			http.Error(w, "Bad Input Request :: "+validMessage, http.StatusBadRequest)
		} else {
			tmsDbResponse := utilX.GetDbDetails(authToken, tenantId, domainConfig.ConfigurationEnv.TmsHost.DbType, w)
			response, errDB := eRef.SRef.MilestonesCountService(tenantId, tmsDbResponse, queryParams)
			if errDB != nil {
				level.Error(logger).Log(
					"op", "tms_db_get",
					"desc", "Error in fetching records for GetMilestonesCount from DB for tenant:"+tenantId,
					"value", errDB.Error())
				http.Error(w, "Internal Server Error", http.StatusInternalServerError)
			} else {
				w.Header().Set("Content-Type", "application/json")
				json.NewEncoder(w).Encode(response)
			}
		}
	}
}

// swagger:route GET /v1/installation/milestonesDetails Milestones MilestonesDetailsSWRequest
//
// Gets Details of Jobs,Trains and Milestones for a Project
//
// This will fetch details of Jobs,Trains and Milestones for a Project
//
//     Schemes: https
//     BasePath: /
//     Version: 0.0.1
//     License: GE Digital
//     Contact: Ganesh Awate<ganesh.awate@bhge.com>
//
//     Consumes:
//     - application/json
//
//     Produces:
//     - application/json
//
//     Security:
//       api_key:
//       oauth: read, write
//
//     SecurityDefinitions:
//     - api_key:
//          type: apiKey
//          name: KEY
//          in: header
//
//     Responses:
//
//       200: InstallCodSuccessResponse
//       500: InstallCodInternalServerErrorResponse
//       400: InstallCodParamErrorResponse
//       401: InstallCodAuthResponse
//       404: InstallCodNotFoundResponse

func (eRef *InstallationMilestonesEndpoint) MilestonesDetails(w http.ResponseWriter, r *http.Request) {

	logger := logConfig.InitLogs()
	queryParams := utilX.ParseQueryParams(r)
	tenantId, authToken := utilX.GetRequestHeader(r)

	if authToken == "" {
		level.Error(logger).Log(
			"op", "Authorization Error",
			"desc", "Invalid/Expired UAA Token")
		http.Error(w, "Invalid/Expired UAA Token", http.StatusUnauthorized)
	} else {
		defaultInputParams := []string{"project-id"}
		validFlag, validMessage := utilX.ValidateRequest(queryParams, defaultInputParams, tenantId)

		if validFlag == false {
			level.Error(logger).Log(
				"op", "decode_config",
				"desc", "Error in Decoding request for MilestonesDetails for tenant:"+tenantId,
				"value", validMessage)
			http.Error(w, "Bad Input Request :: "+validMessage, http.StatusBadRequest)
		} else {
			tmsDbResponse := utilX.GetDbDetails(authToken, tenantId, domainConfig.ConfigurationEnv.TmsHost.DbType, w)
			response, errDB := eRef.SRef.MilestonesDetails(tenantId, tmsDbResponse, queryParams)
			if errDB != nil {
				level.Error(logger).Log(
					"op", "tms_db_get",
					"desc", "Error in fetching records for MilestonesDetails from DB for tenant:"+tenantId,
					"value", errDB.Error())
				http.Error(w, "Internal Server Error", http.StatusInternalServerError)
			} else {
				w.Header().Set("Content-Type", "application/json")
				json.NewEncoder(w).Encode(response)
			}
		}
	}
}

// swagger:route GET /v1/installation/resourceSummary Resources ResourceSummarySWRequest
//
// Gets number of resource assignments
//
// This will fetch number of resource assignments for a Project
//
//     Schemes: https
//     BasePath: /
//     Version: 0.0.1
//     License: GE Digital
//     Contact: Ganesh Awate<ganesh.awate@bhge.com>
//
//     Consumes:
//     - application/json
//
//     Produces:
//     - application/json
//
//     Security:
//       api_key:
//       oauth: read, write
//
//     SecurityDefinitions:
//     - api_key:
//          type: apiKey
//          name: KEY
//          in: header
//
//     Responses:
//
//       200: InstallCodSuccessResponse
//       500: InstallCodInternalServerErrorResponse
//       400: InstallCodParamErrorResponse
//       401: InstallCodAuthResponse
//       404: InstallCodNotFoundResponse

func (eRef *InstallationMilestonesEndpoint) ResourcesSummary(w http.ResponseWriter, r *http.Request) {

	logger := logConfig.InitLogs()
	queryParams := utilX.ParseQueryParams(r)
	tenantId, authToken := utilX.GetRequestHeader(r)

	if authToken == "" {
		level.Error(logger).Log(
			"op", "Authorization Error",
			"desc", "Invalid/Expired UAA Token")
		http.Error(w, "Invalid/Expired UAA Token", http.StatusUnauthorized)
	} else {
		defaultInputParams := []string{"project-id"}
		validFlag, validMessage := utilX.ValidateRequest(queryParams, defaultInputParams, tenantId)

		if validFlag == false {
			level.Error(logger).Log(
				"op", "decode_config",
				"desc", "Error in Decoding request for ResourcesSummary for tenant:"+tenantId,
				"value", validMessage)
			http.Error(w, "Bad Input Request :: "+validMessage, http.StatusBadRequest)

		} else {
			tmsDbResponse := utilX.GetDbDetails(authToken, tenantId, domainConfig.ConfigurationEnv.TmsHost.DbType, w)
			response, errDB := eRef.SRef.ResourcesSummaryService(tenantId, tmsDbResponse, queryParams)
			if errDB != nil {
				level.Error(logger).Log(
					"op", "tms_db_get",
					"desc", "Error in fetching records for ResourcesSummary from DB for tenant:"+tenantId,
					"value", errDB.Error())
				http.Error(w, "Internal Server Error", http.StatusInternalServerError)
			} else {
				w.Header().Set("Content-Type", "application/json")
				json.NewEncoder(w).Encode(response)
			}
		}
	}
}

// swagger:route GET /v1/installation/resourceDetails Resources ResourceDetailsSWRequest
//
// Gets Details of resources
//
// This will fetch details of resources for a Project
//
//     Schemes: https
//     BasePath: /
//     Version: 0.0.1
//     License: GE Digital
//     Contact: Ganesh Awate<ganesh.awate@bhge.com>
//
//     Consumes:
//     - application/json
//
//     Produces:
//     - application/json
//
//     Security:
//       api_key:
//       oauth: read, write
//
//     SecurityDefinitions:
//     - api_key:
//          type: apiKey
//          name: KEY
//          in: header
//
//     Responses:
//
//       200: InstallCodSuccessResponse
//       500: InstallCodInternalServerErrorResponse
//       400: InstallCodParamErrorResponse
//       401: InstallCodAuthResponse
//       404: InstallCodNotFoundResponse

func (eRef *InstallationMilestonesEndpoint) ResourcesDetails(w http.ResponseWriter, r *http.Request) {

	logger := logConfig.InitLogs()
	queryParams := utilX.ParseQueryParams(r)
	tenantId, authToken := utilX.GetRequestHeader(r)

	if authToken == "" {
		level.Error(logger).Log(
			"op", "Authorization Error",
			"desc", "Invalid/Expired UAA Token")
		http.Error(w, "Invalid/Expired UAA Token", http.StatusUnauthorized)
	} else {
		defaultInputParams := []string{"project-id", "resource-status"}
		validFlag, validMessage := utilX.ValidateRequest(queryParams, defaultInputParams, tenantId)

		if validFlag == false {
			level.Error(logger).Log(
				"op", "decode_config",
				"desc", "Error in Decoding request for ResourcesDetails for tenant:"+tenantId,
				"value", validMessage)
			http.Error(w, "Bad Input Request :: "+validMessage, http.StatusBadRequest)

		} else {
			tmsDbResponse := utilX.GetDbDetails(authToken, tenantId, domainConfig.ConfigurationEnv.TmsHost.DbType, w)
			response, errDB := eRef.SRef.ResourcesDetailsService(tenantId, tmsDbResponse, queryParams)
			if errDB != nil {
				level.Error(logger).Log(
					"op", "tms_db_get",
					"desc", "Error in fetching records for ResourcesDetails from DB for tenant:"+tenantId,
					"value", errDB.Error())
				http.Error(w, "Internal Server Error", http.StatusInternalServerError)
			} else {
				w.Header().Set("Content-Type", "application/json")
				json.NewEncoder(w).Encode(response)
			}
		}
	}
}

// swagger:route GET /v1/installation/techQueries TechQueries TechQueriesDetailsSWRequest
//
// Gets Details Missing materials for a Project
//
// This will fetch details of Missing materials for a Project
//
//     Schemes: https
//     BasePath: /
//     Version: 0.0.1
//     License: GE Digital
//     Contact: Ganesh Awate<ganesh.awate@bhge.com>
//
//     Consumes:
//     - application/json
//
//     Produces:
//     - application/json
//
//     Security:
//       api_key:
//       oauth: read, write
//
//     SecurityDefinitions:
//     - api_key:
//          type: apiKey
//          name: KEY
//          in: header
//
//     Responses:
//
//       200: InstallCodSuccessResponse
//       500: InstallCodInternalServerErrorResponse
//       400: InstallCodParamErrorResponse
//       401: InstallCodAuthResponse
//       404: InstallCodNotFoundResponse

func (eRef *InstallationMilestonesEndpoint) TechQueriesDetails(w http.ResponseWriter, r *http.Request) {

	logger := logConfig.InitLogs()
	queryParams := utilX.ParseQueryParams(r)
	tenantId, authToken := utilX.GetRequestHeader(r)

	if authToken == "" {
		level.Error(logger).Log(
			"op", "Authorization Error",
			"desc", "Invalid/Expired UAA Token")
		http.Error(w, "Invalid/Expired UAA Token", http.StatusUnauthorized)
	} else {
		defaultInputParams := []string{"project-id"}
		validFlag, validMessage := utilX.ValidateRequest(queryParams, defaultInputParams, tenantId)

		if validFlag == false {
			level.Error(logger).Log(
				"op", "decode_config",
				"desc", "Error in Decoding request for TechQueriesDetails for tenant:"+tenantId,
				"value", validMessage)
			http.Error(w, "Bad Input Request :: "+validMessage, http.StatusBadRequest)

		} else {
			tmsDbResponse := utilX.GetDbDetails(authToken, tenantId, domainConfig.ConfigurationEnv.TmsHost.DbType, w)
			response, errDB := eRef.SRef.TechQueriesDetailsService(tenantId, tmsDbResponse, queryParams)
			if errDB != nil {
				level.Error(logger).Log(
					"op", "tms_db_get",
					"desc", "Error in fetching records for TechQueriesDetails from DB for tenant:"+tenantId,
					"value", errDB.Error())
				http.Error(w, "Internal Server Error", http.StatusInternalServerError)
			} else {
				w.Header().Set("Content-Type", "application/json")
				json.NewEncoder(w).Encode(response)
			}
		}
	}
}

// swagger:route GET /v1/installation/techQueriesUpdatedDate TechQueries TechQueriesDetailsSWRequest
//
// Gets last updated date
//
// This will fetch last updated date
//
//     Schemes: https
//     BasePath: /
//     Version: 0.0.1
//     License: GE Digital
//     Contact: Ganesh Mali<ganesh.mali@bhge.com>
//
//     Consumes:
//     - application/json
//
//     Produces:
//     - application/json
//
//     Security:
//       api_key:
//       oauth: read, write
//
//     SecurityDefinitions:
//     - api_key:
//          type: apiKey
//          name: KEY
//          in: header
//
//     Responses:
//
//       200: InstallCodSuccessResponse
//       500: InstallCodInternalServerErrorResponse
//       400: InstallCodParamErrorResponse
//       401: InstallCodAuthResponse
//       404: InstallCodNotFoundResponse

func (eRef *InstallationMilestonesEndpoint) TechQueriesUpdatedOn(w http.ResponseWriter, r *http.Request) {

	logger := logConfig.InitLogs()
	queryParams := utilX.ParseQueryParams(r)
	tenantId, authToken := utilX.GetRequestHeader(r)

	if authToken == "" {
		level.Error(logger).Log(
			"op", "Authorization Error",
			"desc", "Invalid/Expired UAA Token")
		http.Error(w, "Invalid/Expired UAA Token", http.StatusUnauthorized)
	} else {
		defaultInputParams := []string{"project-id"}
		validFlag, validMessage := utilX.ValidateRequest(queryParams, defaultInputParams, tenantId)

		if validFlag == false {
			level.Error(logger).Log(
				"op", "decode_config",
				"desc", "Error in Decoding request for TechQueriesUpdatedOn for tenant:"+tenantId,
				"value", validMessage)
			http.Error(w, "Bad Input Request :: "+validMessage, http.StatusBadRequest)

		} else {
			tmsDbResponse := utilX.GetDbDetails(authToken, tenantId, domainConfig.ConfigurationEnv.TmsHost.DbType, w)
			response, errDB := eRef.SRef.TechQueriesUpdatedOnService(tenantId, tmsDbResponse, queryParams)
			if errDB != nil {
				level.Error(logger).Log(
					"op", "tms_db_get",
					"desc", "Error in fetching records for TechQueriesUpdatedOn from DB for tenant:"+tenantId,
					"value", errDB.Error())
				http.Error(w, "Internal Server Error", http.StatusInternalServerError)
			} else {
				w.Header().Set("Content-Type", "application/json")
				json.NewEncoder(w).Encode(response)
			}
		}
	}
}
