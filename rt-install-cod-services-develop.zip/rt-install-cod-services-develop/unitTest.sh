#!/bin/sh

export GOROOT=/usr/local/go
export GOPATH=$WORKSPACE
export GOBIN=$GOPATH/bin
export PATH=$PATH:$GOPATH/bin:$GOBIN:$GOROOT/bin

echo "GOPATH Directory: $GOPATH"
echo "GOROOT Directory: $GOROOT"

cd $WORKSPACE/src/github.build.ge.com/RealTrack/rt-install-cod-services

#echo "Running predeploy from unit test"

#sudo -i ./preDeploy.sh

echo "Running All Test Cases"
pwd

go test ./controller -v
