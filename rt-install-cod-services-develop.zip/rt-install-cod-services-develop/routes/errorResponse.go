/**
@Author: Ganesh Mali
Date: 30-10-2017
Project :rt-install-cod-services
Description:
*/

package routes

type AuthErrorResponse struct {
	Message string`json:"message"`
}

