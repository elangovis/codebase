/**
@Author: Ganesh Mali
Date: 30-10-2017
Project :rt-install-cod-services
Description:
*/

package routes

import (
	config "github.build.ge.com/RealTrack/rt-install-cod-services/config/logs"
	"github.build.ge.com/RealTrack/rt-install-cod-services/install"
	UtilX "github.build.ge.com/RealTrack/rt-install-cod-services/utilx"
	"github.com/go-kit/kit/log"
	"github.com/gorilla/mux"
	"net/http"
	"strings"
)

func getLogger() log.Logger {
	logger := config.InitLogs()
	return logger
}

func HandleRequests() *mux.Router {

	installRepo := install.InstallationMilestonesRepository{}
	installService := install.InstallationMilestonesService{RRef: installRepo}
	installEndpoint := install.InstallationMilestonesEndpoint{SRef: installService}

	// Routes consist of a path and a handler function.
	r := mux.NewRouter()

	r.HandleFunc("/v1/installation/milestonesCount", installEndpoint.MilestonesCount).Methods("GET")
	r.HandleFunc("/v1/installation/milestonesDetails", installEndpoint.MilestonesDetails).Methods("GET")
	r.HandleFunc("/v1/installation/resourceSummary", installEndpoint.ResourcesSummary).Methods("GET")
	r.HandleFunc("/v1/installation/resourceDetails", installEndpoint.ResourcesDetails).Methods("GET")
	r.HandleFunc("/v1/installation/techQueries", installEndpoint.TechQueriesDetails).Methods("GET")
	r.HandleFunc("/v1/installation/techQueriesUpdatedDate", installEndpoint.TechQueriesUpdatedOn).Methods("GET")

	return r

}

/**
Authentication Middleware
*/

func AuthMiddleware(h http.Handler) http.Handler {
	return http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {

		//set common response header across all requests
		//w = UtilX.AddResponseHeader(w)
		if "/swagger" == r.URL.Path {
			h.ServeHTTP(w, r)
			return
		}

		authHeader := r.Header.Get("Authorization")

		//Remove for Production Deployment
		if authHeader == "unittest" {
			if UtilX.ValidateProjectRequest(w, r) {
				h.ServeHTTP(w, r)
			} else {
				http.Error(w, "authorization failed", http.StatusUnauthorized)
			}
		} else {
			if len(authHeader) > 0 {
				authHeader = strings.Replace(authHeader, "bearer ", "", -1)
				authHeader = strings.Replace(authHeader, "Bearer ", "", -1) // Need to check why its
				// returning two different values for UAA token
				response := UtilX.CheckToken(authHeader)

				if response != "error" {
					r.Header.Set("SSO", response)
					if UtilX.ValidateProjectRequest(w, r) {
						h.ServeHTTP(w, r)
					} else {
						http.Error(w, "authorization failed", http.StatusUnauthorized)
					}
				} else {
					UtilX.EncodeResponseWithStatusCode(w, AuthErrorResponse{
						Message: "Autorization Failed , Auth Token Key/Value can't be empty and should be valid"}, http.StatusUnauthorized)
					return
				}
			} else {
				UtilX.EncodeResponseWithStatusCode(w, AuthErrorResponse{
					Message: "Autorization Failed , Auth Token Key/Value can't be empty and should be valid"}, http.StatusUnauthorized)
				return
			}
		}
	})
}
