package utilx

import (
	"database/sql"
	"reflect"
	"regexp"
	"sort"
	"strings"
)

//Error Message Constants
const (
	tenantErrMessage       = "Tenant name and Value can't be empty and should be valid."
	noInputErrMessage      = "Expected Inputs,but no Inputs provided."
	emptyParamErrMessage   = "Empty/Null Value for input(s)- "
	invalidParamErrMessage = "Insufficient/Extraneous Inputs - Please Check Input Names and Number of Inputs."
)

func ValidateRequest(inputParams map[string]string, defaultKeys []string, tenantId string) (bool, string) {
	validationFlag := true
	var ErrMessage string

	//Tenant Validation
	if tenantId == "" {
		validationFlag = false
		ErrMessage = tenantErrMessage
	} else {
		if len(inputParams) == 0 {
			validationFlag = false
			ErrMessage = noInputErrMessage
		} else {
			inputKeys := getKeys(inputParams)
			eqFlag := compareKeys(inputKeys, defaultKeys)

			if eqFlag {
				emptyParamCheck := isEmptyParam(inputParams)
				if len(emptyParamCheck) > 0 {
					validationFlag = false
					ErrMessage = emptyParamErrMessage + (emptyParamCheck)
				}
			} else {
				validationFlag = false
				ErrMessage = invalidParamErrMessage
			}
		}
	}
	return validationFlag, ErrMessage
}

func getKeys(input map[string]string) []string {
	mapKeys := []string{}
	for k, _ := range input {
		mapKeys = append(mapKeys, k)
	}
	return mapKeys
}

func isEmptyParam(inputParams map[string]string) string {
	emptyKeys := ""
	for key, value := range inputParams {
		if value == "" {
			emptyKeys += key + ","
		}
	}
	if len(emptyKeys) > 0 {
		emptyKeys = emptyKeys[0:(len(emptyKeys) - 1)]
	}
	return emptyKeys
}

func compareKeys(defaultKeys []string, inputKeys []string) bool {
	//sorting both inputs String Arrays for deepEqual check
	var eqFlag bool = false
	if len(inputKeys) == len(defaultKeys) {
		//sorting both inputs String Arrays for deepEqual check
		sort.Strings(defaultKeys)
		sort.Strings(inputKeys)
		eqFlag = reflect.DeepEqual(inputKeys, defaultKeys)
	}
	return eqFlag
}

func CleanString(s string) (string, error) {
	reg, err := regexp.Compile("[^A-Za-z0-9]+")
	if err != nil {
		return "", err
	}

	safe := reg.ReplaceAllString(s, "-")
	safe = strings.ToLower(strings.Trim(safe, "-"))

	return safe, err
}

func NewNullString(s string) sql.NullString {
	if len(s) == 0 {
		return sql.NullString{}
	}
	return sql.NullString{
		String: s,
		Valid:  true,
	}
}
