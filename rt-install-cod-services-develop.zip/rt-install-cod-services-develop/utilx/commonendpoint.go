package utilx


/**
@Author: Ganesh Mali
Date: 15-11-2017
Project :rt-install-cod-services
Description:
*/
import (
	"net/http"
	"encoding/json"
	"time"
	"strings"
	"io/ioutil"
	"github.build.ge.com/RealTrack/rt-install-cod-services/common"
	"github.com/go-kit/kit/log/level"
	config "github.build.ge.com/RealTrack/rt-install-cod-services/config/logs"
	domainConfig "github.build.ge.com/RealTrack/rt-install-cod-services/config/domain"
	logConfig "github.build.ge.com/RealTrack/rt-install-cod-services/config/logs"
)

func Ping(w http.ResponseWriter, r *http.Request) {
	json.NewEncoder(w).Encode(time.Now().Local())
}

func GetTokenFromUAA() (string) {
	logger := config.InitLogs()
	valueMap := make(map[string]string)
	headerMap := make(map[string]string)
	var uaaResponse common.UAAResponse

	headerMap["Authorization"] = domainConfig.ConfigurationEnv.Client.Token
	valueMap["client_id"] = domainConfig.ConfigurationEnv.Client.Id
	valueMap["grant_type"] = "client_credentials"
	resp, err := DoHttpFormPost(domainConfig.ConfigurationEnv.API.UAA + "/oauth/token", valueMap, headerMap)

	if err != nil {
		level.Error(logger).Log(
			"op", "http_post",
			"desc", "unable to connect to UAA endpoint:: " + domainConfig.ConfigurationEnv.API.UAA + "/oauth/token",
			"value", err.Error());
		return ""
	} else {
		if resp.StatusCode == 200 {
			responseData, _ := ioutil.ReadAll(resp.Body)
			responseString := string(responseData)
			decoder := json.NewDecoder(strings.NewReader(responseString))
			err := decoder.Decode(&uaaResponse)
			if err != nil {
				level.Error(logger).Log(
					"op", "decode_config",
					"desc", "unable to decode UAA respponse",
					"value", err.Error());
				return ""
			} else {
				level.Debug(logger).Log(
					"op", "http_get",
					"desc", "connected to UAA endpoint:: ",
					"value", domainConfig.ConfigurationEnv.API.UAA + "/oauth/token");
				return "Bearer " + uaaResponse.Access_token;
			}
			return ""
		} else {
			return "";
		}

	}
	return ""
}

func CheckToken(authToken string) (string) {
	type UserProfile struct {
		User_name  string
		User_id    string
		Email      string
		Client_id  string
		Exp        string
		Sub        string
		Iss        string
		Iat        string
		Cid        string
		Grant_type string
		Azp        string
		Auth_time  string
		Zid        string
		Rev_sig    string
		Origin     string
		Revocable  string
	}
	var response = "error";
	var userProfile UserProfile
	logger := config.InitLogs()
	valueMap := make(map[string]string)
	headerMap := make(map[string]string)
	headerMap["Authorization"] = domainConfig.ConfigurationEnv.Client.Token
	valueMap["token"] = authToken

	resp, err := DoHttpFormPost(domainConfig.ConfigurationEnv.API.UAA + "/check_token", valueMap, headerMap)

	if err != nil {
		level.Error(logger).Log(
			"op", "http_get",
			"desc", "unable to connect to UUA service",
			"value", err.Error());
		return response

	}

	if resp != nil {
		if resp.StatusCode == 200 {

			responseData, _ := ioutil.ReadAll(resp.Body)

			responseString := string(responseData)
			level.Debug(logger).Log(
				"op", "http_get",
				"desc", "Auth token successful",
				"value", responseString);
			decoder := json.NewDecoder(strings.NewReader(responseString))
			err := decoder.Decode(&userProfile)
			if err != nil {
				response = userProfile.User_name;
			} else {
				return response
			}
		} else {
			return response
		}
	}

	return response;
}

func getHeaderConfigMap() map[string]string {
	configMap := make(map[string]string)
	configMap["Authorization"] = "Authorization"  // This is 1st Priority
	configMap["Predix-Zone-Id"] = "Predix-Zone-Id"
	//configMap["Content-Type"] = "Content-Type"  Not Mendatory
	return configMap
}

func validateTMSApiHeaderParams(headerMap map[string]string, responseWriter http.ResponseWriter) (common.TMSErrorResponse) {

	if ((len(headerMap) == 0) || (headerMap["Authorization"] == "")) {
		responseWriter.WriteHeader(http.StatusUnauthorized)
		tmsErrorResponse := common.TMSErrorResponse{Error : "unauthorized",
			Error_description: "Full authentication is required to access this resource"}
		EncodeResponse(responseWriter, tmsErrorResponse)
		return tmsErrorResponse
	}

	if ((headerMap["Predix-Zone-Id"] == "" )) {
		responseWriter.WriteHeader(http.StatusBadRequest)
		tmsErrorResponse := common.TMSErrorResponse{Error : "invalid_request",
			Error_description: "No zone specified for zone specific request: " + domainConfig.ConfigurationEnv.TmsHost.Uri}
		EncodeResponse(responseWriter, tmsErrorResponse)
		return tmsErrorResponse
	}

	configMap := getHeaderConfigMap();
	for key, _ := range headerMap {
		if (configMap[key] == "") {
			responseWriter.WriteHeader(http.StatusBadRequest)
			tmsErrorResponse := common.TMSErrorResponse{Error : "invalid_request",
				Error_description: "Predix-Zone-Id or Authorization can't be empty for TMS and are case sensitive"}
			EncodeResponse(responseWriter, tmsErrorResponse)
			return tmsErrorResponse
		}
	}
	return common.TMSErrorResponse{}
}

var GetDbDetails = func(authToken string, tenant string, dbType string, responseWriter http.ResponseWriter) (common.TmsDbResponse) {
	logger := logConfig.InitLogs()
	valueMap := make(map[string]string)
	headerMap := make(map[string]string)

	headerMap["Authorization"] = authToken
	headerMap["Predix-Zone-Id"] = domainConfig.ConfigurationEnv.Predix.ZoneId
	//headerMap["Content-Type"] = domainConfig.ConfigurationEnv.ContentType.Type //not required

	tmsErrorResponse := validateTMSApiHeaderParams(headerMap, responseWriter)
	if (tmsErrorResponse != common.TMSErrorResponse{}) {
		tmsDbResponse := common.TmsDbResponse{}
		tmsDbResponse.TMSErrorResponse = tmsErrorResponse;
		return tmsDbResponse
	}

	resp, err := DoHttpFormGet(domainConfig.ConfigurationEnv.TmsHost.Uri + "/" + tenant + "/service/" +
		dbType, valueMap, headerMap)

	if err != nil {
		level.Error(logger).Log(
			"op", "http_get",
			"desc", "unable to connect to TMS Postgres service",
			"value", err.Error());
		responseWriter.WriteHeader(resp.StatusCode)
		EncodeResponse(responseWriter, common.TMSErrorResponse{Error : "invalid_request",
			Error_description:  "unable to connect to TMS Postgres service"})
		return common.TmsDbResponse{}
	}

	data := make([]common.TmsDbBody, 0)
	if resp.StatusCode == 200 {
		bytes, err := ioutil.ReadAll(resp.Body)
		if (err != nil) {
			level.Error(logger).Log(
				"op", "http_get",
				"desc", "unable to read TMS postgres service response",
				"value", err.Error());
			responseWriter.WriteHeader(resp.StatusCode)
			EncodeResponse(responseWriter, common.TMSErrorResponse{Error : "tms_response_read_error",
				Error_description:  "Error in reading tms response "})
			return common.TmsDbResponse{TmsDbBody: data}
		}

		err = json.Unmarshal(bytes, &data)
		if (err != nil) {
			level.Error(logger).Log(
				"op", "http_get",
				"desc", "unable to parse TMS postgres service response",
				"value", err.Error());
			responseWriter.WriteHeader(resp.StatusCode)
			EncodeResponse(responseWriter, common.TMSErrorResponse{Error : "tms_response_parse_error",
				Error_description:  "Error in parsing tms response "})
			return common.TmsDbResponse{TmsDbBody: data}
		}

		level.Info(logger).Log("op", "http_get",
			"desc", "successfully connected to TMS Postgres service for tenant",
			"value", tenant);
		data[0].TenantId = tenant
		return common.TmsDbResponse{TmsDbBody: data}
	} else {
		responseWriter.WriteHeader(resp.StatusCode)
		EncodeResponse(responseWriter, common.TMSErrorResponse{Error : "invalid_tenant",
			Error_description:  "Tenant does not exist"})
		return common.TmsDbResponse{TmsDbBody: data}
	}
}





//Project Access Check service
func ValidateProjectRequest(w http.ResponseWriter, r *http.Request) (bool) {
	logger := logConfig.InitLogs()

	if (r.Method == "GET") {

		param := ParseQueryParams(r)
		projectId := param["project-id"]
		sso := r.Header.Get("SSO")
		tenantId := r.Header.Get("tenantName")
		level.Info(logger).Log("op", "Request Interceptor GET",
			"desc", "ProjectId, sso",
			"value", projectId,
			"value", sso);


		if (projectId != ""  && sso != "") {
			authToken := GetTokenFromUAA()
			if authToken == ""{
				level.Error(logger).Log(
					"op", "Authorization Error",
					"desc", "Invalid/Expired UAA Token")
				http.Error(w, "Invalid/Expired UAA Token", http.StatusUnauthorized)
			}else {
				tmsDbResponse := GetDbDetails(authToken, tenantId, domainConfig.ConfigurationEnv.TmsHost.DbType, w)
				y, errDB := CheckProjectAccessDao(sso, projectId, tmsDbResponse, tenantId)
				level.Info(logger).Log("op", "Request Interceptor GET",
					"desc", "DB flag",
					"value", y["checkFlag"][0]);
				if errDB != nil {
					level.Error(logger).Log("DB ERR", errDB.Error())
					return false
				} else {
					if (y["checkFlag"][0] == "N") {
						return false
					}
				}
			}
		} else {
			return true
		}
	}
	return true
}