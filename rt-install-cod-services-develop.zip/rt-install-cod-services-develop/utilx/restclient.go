package utilx

import (
	"net/http"
	"net/url"
	"strings"
	"github.com/go-kit/kit/log/level"
	logConfig "github.build.ge.com/RealTrack/rt-install-cod-services/config/logs"
)

func DoHttpGet(url string) (*http.Response, error) {

	client := &http.Client{}
	req, err := http.NewRequest("GET", url, nil)

	logger := logConfig.InitLogs()

	if (err != nil) {
		level.Error(logger).Log(
			"op", "http_get",
			"desc", "unbale to make HTTP_GET request",
			"value", err.Error())
		return nil ,err
	}

	res, err := client.Do(req)

	if (err != nil) {
		level.Error(logger).Log(
			"op", "write_response",
			"desc", "unbale to fetch HTTP_GET response",
			"value", err.Error());
		return nil ,err
	}

	return res, err
}

func DoHttpFormGet(urlStr string, valueMap  map[string]string, headerMap map[string]string) (*http.Response, error) {
	requestType := "http_get"
	logBefore(urlStr, requestType)

	client := http.Client{}
	form := url.Values{}

	for key, value := range valueMap {
		form.Add(key, value)
	}

	req, err := http.NewRequest("GET", urlStr, nil)
	logger := logConfig.InitLogs()

	if (err != nil) {
		level.Error(logger).Log(
			"op", "http_get",
			"desc", "unbale to make" + requestType + " request",
			"value", err.Error())
		return nil ,err

	}

	//req, _ := http.NewRequest("POST", urlStr, strings.NewReader(form.Encode())) why not allowed
	req.PostForm = form
	for key, value := range headerMap {
		req.Header.Add(key, value)
	}
	resp, err := client.Do(req)

	if (err != nil) {
		level.Error(logger).Log(
			"op", "write_response",
			"desc", "unbale to make" + requestType + " response",
			"value", err.Error());
		return nil ,err
	}

	logAfter(urlStr, requestType)
	return resp, err
}

func DoHttpFormPost(urlStr string, valueMap  map[string]string, headerMap map[string]string) (*http.Response, error) {
	requestType := "http_post"
	logBefore(urlStr, requestType)

	client := http.Client{}
	form := url.Values{}

	for key, value := range valueMap {
		form.Add(key, value)
	}
	req, err := http.NewRequest("POST", urlStr, strings.NewReader(form.Encode()))
	logger := logConfig.InitLogs()

	if (err != nil) {
		level.Error(logger).Log(
			"op", "http_get",
			"desc", "unbale to make" + requestType + " request",
			"value", err.Error())
		return nil ,err

	}

	req.PostForm = form

	for key, value := range headerMap {
		req.Header.Add(key, value)
	}

	req.Header.Add("Content-Type", "application/x-www-form-urlencoded")

	resp, err := client.Do(req)

	if (err != nil) {
		level.Error(logger).Log(
			"op", "write_response",
			"desc", "unbale to fetch " + requestType + " response",
			"value", err.Error());
		return nil ,err

	}

	logAfter(urlStr, requestType)
	return resp, err
}

func DoHttpPut(urlStr string, headerMap map[string]string, sso string, role string) (*http.Response, error) {
	requestType := "http_put"
	logBefore(urlStr, requestType)

	client := http.Client{}

	data := "{\"subjectIdentifier\":\"$SSO\",\"attributes\":[{\"name\":\"role\",\"value\":\"$ROLE\",\"issuer\":\"https://acs.attributes.int\"}]}"
	data = strings.Replace(data, "$SSO", sso, -1)
	data = strings.Replace(data, "$ROLE", role, -1)
	req, err := http.NewRequest("PUT", urlStr, strings.NewReader(data))

	logger := logConfig.InitLogs()

	if (err != nil) {
		level.Error(logger).Log(
			"op", "http_get",
			"desc", "unbale to make" + requestType + " request",
			"value", err.Error())
		return nil ,err
	}

	for key, value := range headerMap {
		req.Header.Add(key, value)
	}

	req.Header.Add("Content-Type", "application/x-www-form-urlencoded")

	resp, err := client.Do(req)

	if (err != nil) {
		level.Error(logger).Log(
			"op", "write_response",
			"desc", "unbale to fetch " + requestType + " response",
			"value", err.Error());
		return nil ,err

	}

	logAfter(urlStr, requestType)
	return resp, err
}

func DoHttpDelete(urlStr string, headerMap map[string]string, sso string, role string) (*http.Response, error) {
	requestType := "http_delete"
	logBefore(urlStr, requestType)
	client := http.Client{}

	data := ""
	req, err := http.NewRequest("DELETE", urlStr, strings.NewReader(data))

	logger := logConfig.InitLogs()
	if (err != nil) {
		level.Error(logger).Log(
			"op", "http_get",
			"desc", "unbale to make" + requestType + " request",
			"value", err.Error())
		return nil ,err

	}

	for key, value := range headerMap {
		req.Header.Add(key, value)
	}

	req.Header.Add("Content-Type", "application/x-www-form-urlencoded")

	resp, err := client.Do(req)

	if (err != nil) {
		level.Error(logger).Log(
			"op", "http_get",
			"desc", "unbale to fetch " + requestType + " response",
			"value", err.Error())
		return nil , err
	}

	logAfter(urlStr, requestType)
	return resp, err
}

func logBefore(urlStr string, requestType  string) {
	logger := logConfig.InitLogs()
	level.Info(logger).Log("op", requestType,
		"desc", "Endpoint Called : ",
		"value", urlStr);
}

func logAfter(urlStr string, requestType  string) {
	logger := logConfig.InitLogs()
	level.Info(logger).Log("op", requestType,
		"desc", "Endpoint Executed : ",
		"value", urlStr);
}
