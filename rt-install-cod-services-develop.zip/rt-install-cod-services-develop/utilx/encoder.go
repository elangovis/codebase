/**
@Author: Ganesh Mali
Date: 15-11-2017
Project :rt-install-cod-services
Description:
*/
package utilx

import (
	"encoding/json"
	"net/http"
	"github.com/go-kit/kit/log/level"
	logConfig "github.build.ge.com/RealTrack/rt-install-cod-services/config/logs"
	"bytes"
	"io"
)

func EncodeResponseWithStatusCode(w http.ResponseWriter, data interface{}, code int) {
	logger := logConfig.InitLogs()
	w.WriteHeader(code)
	w = AddResponseHeader(w)
	if j, err := json.Marshal(data); err == nil {
		_, err := w.Write(j)
		if (err != nil) {
			level.Error(logger).Log(
				"op", "write_response",
				"desc", "unbale to write response ",
				"value", err.Error());
		}
	}

}

func EncodeResponse(w http.ResponseWriter, data interface{}) {
	logger := logConfig.InitLogs()
	w = AddResponseHeader(w)
	if j, err := json.Marshal(data); err == nil {
		_, err := w.Write(j)
		if (err != nil) {
			level.Error(logger).Log(
				"op", "write_response",
				"desc", "unbale to write response ",
				"value", err.Error());
		}
	}
}

func AddResponseHeader(w http.ResponseWriter) http.ResponseWriter {
	w.Header().Set("Access-Control-Allow-Origin", "*")
	w.Header().Set("Access-Control-Allow-Methods", "POST, GET, OPTIONS, PUT, DELETE")
	w.Header().Set("Access-Control-Allow-Headers", "Accept, Content-Type, Content-Length, Accept-Encoding, X-CSRF-Token, Authorization")
	return w
}

func EncodeFileResponse(w http.ResponseWriter, data []byte, fileName string) {
	logger := logConfig.InitLogs()
	w.Header().Set("Content-Type", "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet; application/vnd.ms-excel")
	w.Header().Set("Content-Disposition", "attachment;filename=" + fileName)
	r := bytes.NewReader(data)
	_,err:=io.Copy(w, r)
	if err != nil {
		level.Error(logger).Log(
			"op", "write_response",
			"desc", "unable to marshal data to an excel response ",
			"value", err.Error());
	}

}