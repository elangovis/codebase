/**
@Author: Ganesh Mali
Date: 15-11-2017
Project :rt-install-cod-services
Description:
*/
package utilx

import (
	"net/http"
	"io/ioutil"
	"github.com/go-kit/kit/log/level"
	config "github.build.ge.com/RealTrack/rt-install-cod-services/config/logs"
)

func GetRequestHeader(r *http.Request) (string, string) {
	tenantId := r.Header.Get("tenantName")
	authToken := GetTokenFromUAA()
	return tenantId, authToken
}

func GetQueryParams(r *http.Request) (map[string][]string) {
	return r.URL.Query()
}

func GetRequestBody(r *http.Request) ([]byte) {
	logger := config.InitLogs()
	body, err := ioutil.ReadAll(r.Body)
	if err != nil {
		level.Error(logger).Log(
			"op", "post",
			"desc", "Error in reading request body ",
			"value", err.Error());
	}
	level.Debug(logger).Log(
		"op", "post",
		"desc", "request_body",
		"value", string(body))
	return body
}

//Parse Input request for Get Requests
func ParseQueryParams(r *http.Request) (map[string]string) {
	inputMap:= r.URL.Query()
	parsedInput:= make(map[string]string)
	for key,value := range inputMap {
		//since there wil always be a single value for one Input Param
		parsedInput[key] = value[0]
	}
	return parsedInput
}