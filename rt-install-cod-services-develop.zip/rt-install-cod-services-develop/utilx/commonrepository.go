/**
@Author: Ganesh Mali
Date: 15-11-2017
Project :rt-install-cod-services
Description:
*/

package utilx

import (
	"github.com/go-kit/kit/log/level"
	config "github.build.ge.com/RealTrack/rt-install-cod-services/config/logs"
	rtdb "github.build.ge.com/RealTrack/rt-install-cod-services/db"
	"github.build.ge.com/RealTrack/rt-install-cod-services/common"
	"gopkg.in/axiomzen/null.v6"
	"github.com/jmoiron/sqlx"
)

func CheckProjectAccessDao(sso string,projectId string,tmsDbResponse common.TmsDbResponse, tenantId string)(map[string][]string, error){
	logger := config.InitLogs()
	var resFlag []string
	x := make(map[string][]string)
	connection,errConn := rtdb.OpenConnection(tmsDbResponse, logger)
	if errConn != nil{
		return x,errConn
	}
	defer connection.Close()
	sqlString := "select rt_app.check_project_access($1,$2)"
	level.Info(logger).Log("op", "db_fetch", "desc", "CheckProjectAccessDao", "projectId", projectId, "SSO", sso);
	err := connection.Select(&resFlag, sqlString, sso, projectId)
	x["checkFlag"] = resFlag
	return x, err
}



//Common Service to Get Last Update Date
func GetUpdateDate (connection *sqlx.DB,columnName string,tableName string,paramValue map[string]string,paramKey string ) (null.String, error){

	var errUpdateDate error
	var sqlUpdateDate string
	var UpdateDate []null.String
	var UpdateDateResponse null.String

	if paramValue["project-id"] != "" {
		sqlUpdateDate = "SELECT COALESCE(to_char(max("+columnName+"), 'DD-MON-YYYY'),'') as UpdateDate " +
			"FROM rt_app."+tableName+" where "+paramKey+" = $1"
		errUpdateDate = connection.Select(&UpdateDate, sqlUpdateDate, paramValue["project-id"])
	} else {
		sqlUpdateDate = "SELECT COALESCE(to_char(max("+columnName+"), 'DD-MON-YYYY'),'') as UpdateDate " +
			"FROM rt_app."+tableName
		errUpdateDate = connection.Select(&UpdateDate, sqlUpdateDate)
	}
	if(errUpdateDate == nil){
		UpdateDateResponse=UpdateDate[0];
	}
	return UpdateDateResponse,errUpdateDate
}