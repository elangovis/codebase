package utilx

type ErrorResponse struct {
	Status int    `json:"status,omitempty"`
	Error  string `json:"error,omitempty"`
}

type Created struct {
	Status  int    `json:"status,omitempty"`
	Message string `json:"message,omitempty"`
	Id      int    `json:"id,omitempty"`
}

type Deleted struct {
	Status  int    `json:"status,omitempty"`
	Message string `json:"message,omitempty"`
}

type Updated struct {
	Status  int    `json:"status,omitempty"`
	Message string `json:"message,omitempty"`
}


