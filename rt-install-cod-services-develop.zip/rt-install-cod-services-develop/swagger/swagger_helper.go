package swagger

import (
"fmt"
"net/http"
"html/template"
)

const SwaggerContent = `
	<!DOCTYPE html>
	<html lang="en">
	  <head>
		<meta charset="UTF-8">
		<title>Swagger UI</title>
		<link href="https://fonts.googleapis.com/css?family=Open+Sans:400,700|Source+Code+Pro:300,600|Titillium+Web:400,600,700" rel="stylesheet">
		<link rel="stylesheet" type="text/css" src="https://swagger-io-assets.run.aws-usw02-pr.ice.predix.io/static/css/swagger-ui.css"/>
		<script src="https://swagger-io-assets.run.aws-usw02-pr.ice.predix.io/static/js/swagger-ui-bundle.js"></script>
		<script src="https://swagger-io-assets.run.aws-usw02-pr.ice.predix.io/static/js/swagger-ui-standalone-preset.js"></script>
	  </head>
	  <body>
		<div id="swagger-ui"></div>
		<script>
		  function loadSwaggerData(data) {
			// Build a system
			const ui = SwaggerUIBundle({
			  spec: data,
			  dom_id: '#swagger-ui',
			  presets: [
				SwaggerUIBundle.presets.apis,
				SwaggerUIStandalonePreset
			  ],
			  plugins: [
				SwaggerUIBundle.plugins.DownloadUrl
			  ],
			  layout: "StandaloneLayout"
			})
			window.ui = ui
		  }
		  window.onload = function() {
		  	var swaggerJson = {{.SwaggerJson}}
			loadSwaggerData(JSON.parse(swaggerJson));
		  }
		</script>
	  </body>
	</html>
`

func ServeTemplate(w http.ResponseWriter, swaggerJson string) {
	type Data struct {
		SwaggerJson string
	}
	data := Data{SwaggerJson: swaggerJson}
	t := template.New("index.html")

	t, err := t.Parse(SwaggerContent)

	if err != nil {
		fmt.Printf("template Parsing error: %v\n", err)
	}
	t.Execute(w, &data)
}